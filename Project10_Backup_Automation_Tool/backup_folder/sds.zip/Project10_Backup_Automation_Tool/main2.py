import os
from time import sleep
import datetime
import shutil
from pathlib import Path

def naming_func(naming_option):
    if naming_option == "y":
        return input("Enter the name of the backup file: ").strip().lower()
    else:
        today = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"backup_{today}"

def make_backup(source, destination, backup_name, file_type):
    source_path = Path(source)
    if not source_path.exists():
        print("INVALID SOURCE PATH")
        return

    backup_path = os.path.join(destination, backup_name)
    
    if file_type == "1":
        shutil.make_archive(backup_path, 'zip', root_dir=source)
    elif file_type == "2":
        shutil.make_archive(backup_path, 'gztar', root_dir=source)
    elif file_type == "3":
        shutil.make_archive(backup_path, 'bztar', root_dir=source)
    else:
        print("Invalid file type. Using ZIP by default.")
        shutil.make_archive(backup_path, 'zip', root_dir=source)

    print(f"Backup done: {backup_path}")

# Main flow
print("For backup, provide the path and type of compressed file (ZIP, TAR.GZ, TAR.BZ2)")
sleep(2)

source = input("Please enter the Source Path:\n")
destination = "/Users/apple/Desktop/TechWithHer/DevOps-Projects-in-Python/Project10_Backup/backup_folder"
print(f"Destination path: {destination}")
sleep(1)

naming_option = input("Do you want to name the backup? (Y/N): ").strip().lower()
backup_name = naming_func(naming_option)

file_type = input("Enter type: 1 - ZIP, 2 - TAR.GZ, 3 - TAR.BZ2:\n")
make_backup(source, destination, backup_name, file_type)
