import os
from time import sleep
import datetime
import shutil
from pathlib import Path



#if the user selects the naming option, this function will run.
def naming_func(naming_option):
        if naming_option == "y":
            name = input("Enter the name of the folder: ").strip().lower()
            return name 
        elif naming_option == "n":
            print("Using the system to generate the name")
            return 0
        else:
            print("Invalid input. Session Terminated")

#selecting file_type and making the backup using backup_name by default or by backup_name selected by the user
def make_backup(source, destination, backup_name):
    while source.exists():
        if file_type == "1":
            print("Using the file type ZIP to generate a backup")
            today = datetime.date.today()
            backup_name = os.path.join(destination,f"backup_{today}.ZIP") #giving the complete path of the backup
            shutil.make_archive(backup_name, 'ZIP', source) #The actual backup is being generated
        elif file_type == "2":
            backup_name = os.path.join(destination,f"backup_{backup_name}.TAR.ZIP") #giving the complete path of the backup
            shutil.make_archive(backup_name, 'TAR.ZIP', source) #The actual backup is being generated
        elif file_type == "3":
            backup_name = os.path.join(destination,f"backup_{backup_name}.TAR.BZ2") #giving the complete path of the backup
            shutil.make_archive(backup_name, 'TAR.BZ2', source) #The actual backup is being generated
        else:
            print("Using the file type ZIP to generate a backup")
            today = datetime.date.today()
            backup_name = os.path.join(destination,f"backup_{today}.ZIP") #giving the complete path of the backup
            shutil.make_archive(backup_name, 'ZIP', source) #The actual backup is being generated
       
    print("INVALID SOURCE PATH")

FILE_TYPE = input("Please enter the FILE_TYPE (ZIP, TAR.ZIP OR TAR.BZ2) for BACKUP_FILE: ")
sleep(3)
SOURCE = input("Please enter the Source Path- \n")
sleep(2)
destination = "/Users/apple/Desktop/TechWithHer/DevOps-Projects-in-Python/Project10_Backup/backup_folder"
print (f"Please note the destination path will be: {destination}")
sleep(2)
naming_option = input("Do you want to name the folder yourself? (Y/N): ").strip().lower()
backup_name = naming_func(naming_option)
make_backup(SOURCE, destination, backup_name)
#----
print(f"Backup Done. The File Name is {backup_name}")









